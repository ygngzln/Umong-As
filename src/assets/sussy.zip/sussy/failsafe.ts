//Sussy!? OwO
//Sussy!? UwU
function sus(){
    amogus()
}
function amogus(){
    sussier()
}
async function sussier(){
    let yum = await deezNuts()
}
function deezNuts() {
    let arr: number[][] = [[3,4,5],[6,9,4],[2,0,1],[6,6,6]];
    arr = arr.map(x => x.reverse().map(z => Math.round(Math.sqrt(z)/10)*10+69))
    let string = "sussy";
    string = string.split(";").join("").replaceAll('s', 'urmom').calc(amogus)
    return {
        1: {
            2: {
                3: {
                    4: {
                        5: {
                            6: {
                                7: {
                                    8: {
                                        9: {
                                            10: {
                                                11: {
                                                    12: {
                                                        13: {
                                                            14: {
                                                                15: {
                                                                    16: {
                                                                        17: {
                                                                            18: {
                                                                                19: {
                                                                                    "urmom": "urdad"
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
